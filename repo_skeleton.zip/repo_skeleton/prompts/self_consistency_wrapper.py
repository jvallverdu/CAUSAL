"""
Self-consistency wrapper.

Generates K independent reasoning trajectories under the Guided-CoT prompt,
varying only the inference seed in {1,2,3,4,5}. The final answer is the
majority vote across the K samples; ties are broken by selecting the
trajectory with the highest sequence log-probability under the model.

This implementation matches Section 3.1 (paragraph "Self-Consistency") of
the paper.
"""
from __future__ import annotations

import json
import math
from collections import Counter
from pathlib import Path
from typing import List, Tuple

from runners.ollama_client import OllamaClient

K_SAMPLES = 5
SEEDS = [1, 2, 3, 4, 5]
TEMPERATURE = 0.7
TOP_P = 0.9
TOP_K = 40
MAX_TOKENS = 7900


def run_self_consistency(client: OllamaClient, model: str, question: str,
                         prompt_template: str) -> dict:
    """Run K samples and aggregate.

    Returns a dict with the final answer, the per-sample answers and
    log-probabilities, and the tie-breaking trace.
    """
    prompt = prompt_template.replace("##question##", question)

    samples: List[Tuple[str, float, str]] = []   # (answer, logprob, raw)
    for seed in SEEDS:
        resp = client.generate(
            model=model,
            prompt=prompt,
            options={
                "seed": seed,
                "temperature": TEMPERATURE,
                "top_p": TOP_P,
                "top_k": TOP_K,
                "num_predict": MAX_TOKENS,
            },
        )
        ans = _extract_answer(resp["response"])
        logprob = resp.get("total_logprob", float("nan"))
        samples.append((ans, logprob, resp["response"]))

    # Majority vote with log-prob tie-break
    counts = Counter(a for a, _, _ in samples if a in {"YES", "NO"})
    if not counts:
        final = "PARSE_FAIL"
        decided_by = "no_valid_samples"
    else:
        top_count = max(counts.values())
        top = [a for a, c in counts.items() if c == top_count]
        if len(top) == 1:
            final = top[0]
            decided_by = "majority"
        else:
            # tie: pick the answer of the trajectory with highest logprob
            tied = [(a, lp) for a, lp, _ in samples if a in top]
            best = max(tied, key=lambda x: x[1] if not math.isnan(x[1]) else -math.inf)
            final = best[0]
            decided_by = "logprob_tiebreak"

    return {
        "final_answer": final,
        "decided_by": decided_by,
        "samples": [{"seed": s, "answer": a, "logprob": lp,
                      "raw_response": r} for (a, lp, r), s in zip(samples, SEEDS)],
        "vote_counts": dict(counts),
    }


def _extract_answer(raw: str) -> str:
    """Try to parse {"final_answer": "..."} from a JSON-formatted response."""
    try:
        # Tolerate code fences
        body = raw
        if "```" in body:
            body = body.split("```")[1]
            if body.startswith("json"):
                body = body[4:]
        d = json.loads(body)
        v = d.get("final_answer", "").strip().upper()
        return v if v in {"YES", "NO"} else "PARSE_FAIL"
    except Exception:
        return "PARSE_FAIL"
