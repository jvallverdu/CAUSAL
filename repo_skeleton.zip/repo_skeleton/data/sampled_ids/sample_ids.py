"""
Deterministic 500-item sampler used in the paper.

Reproduces the exact item IDs in `cladder_500.json` and `corr2cause_500.json`
when run with seed=42. No stratification by question type or difficulty.

Usage:
    python data/sampled_ids/sample_ids.py \
        --benchmark cladder \
        --source path/to/cladder/v1.5/cladder-v1-q-balanced.json \
        --n 500 \
        --seed 42 \
        --out data/sampled_ids/cladder_500.json
"""
from __future__ import annotations

import argparse
import json
import random
from pathlib import Path


def sample_cladder(source: Path, n: int, seed: int) -> list[int]:
    with open(source) as f:
        items = json.load(f)
    rng = random.Random(seed)
    chosen = rng.sample(items, n)
    return sorted([int(it["question_id"]) for it in chosen])


def sample_corr2cause(source: Path, n: int, seed: int) -> list[int]:
    """corr2cause is a HuggingFace dataset; the local source should be a JSONL
    of {"id": <int>, "input": ..., "label": ...} entries from the test split."""
    items = []
    with open(source) as f:
        for line in f:
            line = line.strip()
            if line:
                items.append(json.loads(line))
    rng = random.Random(seed)
    chosen = rng.sample(items, n)
    return sorted([int(it["id"]) for it in chosen])


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--benchmark", choices=["cladder", "corr2cause"], required=True)
    ap.add_argument("--source", type=Path, required=True,
                    help="Path to the unmodified benchmark file.")
    ap.add_argument("--n", type=int, default=500)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()

    if args.benchmark == "cladder":
        ids = sample_cladder(args.source, args.n, args.seed)
    else:
        ids = sample_corr2cause(args.source, args.n, args.seed)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps({
        "benchmark": args.benchmark,
        "n": args.n,
        "seed": args.seed,
        "source_file": str(args.source.name),
        "ids": ids,
    }, indent=2))
    print(f"[OK] wrote {len(ids)} IDs to {args.out}")


if __name__ == "__main__":
    main()
