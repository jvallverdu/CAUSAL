# Ablation runs (Section 5.8)

This directory contains the per-item outputs of the multi-agent
hyperparameter ablation reported in Section 5.8 and Table 12 of the paper.

## Grid

| Knob | Levels                        |
|------|-------------------------------|
| A    | {2, 3, 5}                     |
| T    | {0.6, 0.8, 0.9, 1.0}          |
| R    | {1, 2, 4}                     |
| V    | {on, off}                     |

Total: 3 x 4 x 3 x 2 = 72 cells. The consensus threshold tau_c is held
fixed at 0.9 throughout this main grid; a separate auxiliary sweep over
tau_c is documented below.

## Status of completion

* **51 of 72** main-grid cells completed before the ARRAY revision deadline.
* **21 cells** (all in the A=5 block) are released as `in_progress.json`
  placeholders; full predictions will be added in the camera-ready version.
* The 3 auxiliary tau_c-sweep cells (51% / 66% / 90%, all at A=3, T=0.7,
  R=4, V=on) are in `aux_tau_c_sweep/`.

## Per-cell layout

Each completed cell is a directory named with the convention
`A{n}_T{t}_R{r}_V{on|off}` containing one JSON file per item with the
following schema:

```json
{
  "config": "A2_T0.6_R1_Voff",
  "question": "<original CLadder question>",
  "ground_truth": "YES" | "NO",
  "final_answer": "YES" | "NO" | "PARSE_FAIL",
  "rounds_used": 1,
  "votes": {"YES": 2} | {"NO": 2} | {"YES": 1, "NO": 1},
  "decided_by": "consensus" | "timeout_plurality",
  "conversation": [
    {"agent": "R1", "round": 1, "message": "..."},
    ...
  ],
  "input_tokens": [{"R1": 203}, {"R2": 203}],
  "latency_seconds": 21.59
}
```

> **Important note (acknowledged in Section 5.8 of the paper):** the
> per-item JSONs in the ablation directory record the model's prediction
> but the per-item ground-truth label was not paired against predictions
> at write time due to a logging issue. As a result, the ablation analysis
> in the paper reports **agreement-implied accuracy intervals** rather than
> direct accuracy. Direct accuracies will be added in the camera-ready
> version once the predictions have been re-joined against the source
> CLadder dataset by item ID.

## grid_index.csv

`grid_index.csv` is the master index that lists, for every cell, the
pairwise agreement against the reference configuration
(A=3, T=0.7, R=4, V=on, whose ground-truth accuracy is 78.0%) plus
mean / median / max latency.
