"""Single-agent runner for vanilla / simple_cot / guided_cot.

Reads a sampled-ID file, runs the chosen prompt against the given Ollama
model on every item, and writes one JSON file per item to the output
directory. The output JSON conforms to the schema documented in
`docs/output_schema.md`.

Example:
    python runners/single_agent.py \
        --model qwen3:4b-instruct \
        --strategy guided_cot \
        --benchmark cladder \
        --ids data/sampled_ids/cladder_500.json \
        --benchmark-source path/to/cladder.json \
        --out outputs/cladder/qwen3-4b-instruct/guided_cot/
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

from runners.ollama_client import OllamaClient, DECODING_GREEDY, DECODING_THINKING

PROMPT_FILES = {
    "vanilla": "prompts/vanilla.txt",
    "simple_cot": "prompts/simple_cot.txt",
    "guided_cot": "prompts/guided_cot.txt",
}


def parse_answer(raw: str) -> str:
    try:
        body = raw
        if "```" in body:
            body = body.split("```")[1]
            if body.startswith("json"):
                body = body[4:]
        d = json.loads(body)
        v = d.get("final_answer", "").strip().upper()
        return v if v in {"YES", "NO"} else "PARSE_FAIL"
    except Exception:
        return "PARSE_FAIL"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--strategy", choices=PROMPT_FILES.keys(), required=True)
    ap.add_argument("--benchmark", choices=["cladder", "corr2cause"], required=True)
    ap.add_argument("--ids", type=Path, required=True)
    ap.add_argument("--benchmark-source", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--thinking", action="store_true",
                    help="Use the thinking-mode decoding budget.")
    args = ap.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    template = Path(PROMPT_FILES[args.strategy]).read_text()
    ids = json.loads(args.ids.read_text())["ids"]
    items = _load_items(args.benchmark, args.benchmark_source, set(ids))

    client = OllamaClient()
    decoding = DECODING_THINKING if args.thinking else DECODING_GREEDY
    decoding["seed"] = args.seed

    for item_id, question, gt in items:
        out_file = args.out / f"{item_id}.json"
        if out_file.exists():
            continue
        prompt = template.replace("##question##", question)
        t0 = time.perf_counter()
        resp = client.generate(args.model, prompt, options=decoding)
        latency = time.perf_counter() - t0
        out_file.write_text(json.dumps({
            "item_id": item_id,
            "question": question,
            "ground_truth": gt,
            "raw_response": resp["response"],
            "predicted": parse_answer(resp["response"]),
            "latency_seconds": latency,
            "input_tokens": resp.get("prompt_eval_count"),
            "output_tokens": resp.get("eval_count"),
            "model": args.model,
            "strategy": args.strategy,
            "decoding": decoding,
            "seed": args.seed,
        }, indent=2))
    print(f"[OK] wrote {len(items)} items to {args.out}")


def _load_items(benchmark: str, source: Path, id_set: set[int]):
    """Load (item_id, question, ground_truth) tuples for the requested IDs."""
    if benchmark == "cladder":
        data = json.loads(source.read_text())
        for it in data:
            qid = int(it["question_id"])
            if qid in id_set:
                yield qid, it["question"], it["answer"].strip().upper()
    else:
        with open(source) as f:
            for line in f:
                if not line.strip():
                    continue
                it = json.loads(line)
                qid = int(it["id"])
                if qid in id_set:
                    yield qid, it["input"], it["label"].strip().upper()


if __name__ == "__main__":
    main()
