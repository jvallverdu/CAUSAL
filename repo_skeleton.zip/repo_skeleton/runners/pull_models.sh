#!/usr/bin/env bash
# Pull every model used in the paper at the exact quantization tags.
set -euo pipefail

MODELS=(
  "qwen3:4b-instruct-2507"
  "qwen3:4b-thinking-2507"
  "qwen2.5:7b"
  "falcon3:7b-instruct"
  "llama3.1:8b-instruct"
  "gemma3:12b-instruct"
  "phi4:14b"
  "deepseek-r1:8b-distill-llama"
  "qwq:32b"
)

for m in "${MODELS[@]}"; do
  echo "[pull] $m"
  ollama pull "$m"
done

echo "[OK] all models present in the local Ollama registry"
