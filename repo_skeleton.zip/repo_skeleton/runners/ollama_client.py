"""Lightweight wrapper around the official Ollama Python client.

This wrapper standardises the request shape used in the paper so that the
exact same call site is shared by the single-agent, self-consistency, and
multi-agent runners.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import ollama


@dataclass
class OllamaClient:
    host: str = "http://localhost:11434"
    timeout: float = 600.0

    def __post_init__(self) -> None:
        self._client = ollama.Client(host=self.host, timeout=self.timeout)

    def generate(self, model: str, prompt: str,
                 options: dict[str, Any] | None = None,
                 system: str | None = None) -> dict[str, Any]:
        """Run a single completion. Returns a dict with at minimum:
            {"response": <str>, "total_duration": <ns>, "eval_count": <int>,
             "prompt_eval_count": <int>}.
        """
        kwargs = {
            "model": model,
            "prompt": prompt,
            "options": options or {},
            "stream": False,
        }
        if system is not None:
            kwargs["system"] = system
        return self._client.generate(**kwargs)


# Decoding parameter blocks used in the paper -------------------------------

DECODING_GREEDY = {
    "temperature": 0.1,
    "top_p": 0.9,
    "top_k": 40,
    "num_predict": 7900,
}

DECODING_SAMPLE = {
    "temperature": 0.7,
    "top_p": 0.9,
    "top_k": 40,
    "num_predict": 7900,
}

DECODING_THINKING = {
    "temperature": 0.7,
    "top_p": 0.9,
    "top_k": 40,
    "num_predict": 32000,
}
