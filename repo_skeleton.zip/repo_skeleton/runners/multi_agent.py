"""Same-model multi-agent runner.

Implements Algorithm 1 of the paper: A reasoners + (optional) validator,
running for up to R rounds, terminating early when consensus tau_c is met.
All agents are instantiated from the same base model unless `--het` is
passed (in which case the heterogeneous configurations of `prompts/het*.json`
are used; see runners/multi_agent_het.py for the dispatcher).

Example (reference configuration A=3, tau_c=0.9, R=4, V=on, T=0.7):

    python runners/multi_agent.py \
        --model qwen3:4b-instruct \
        --benchmark cladder \
        --ids data/sampled_ids/cladder_500.json \
        --benchmark-source path/to/cladder.json \
        --A 3 --tau_c 0.9 --R 4 --V on --T 0.7 \
        --out outputs/cladder/qwen3-4b-instruct/multi_agent/
"""
from __future__ import annotations

import argparse
import json
import time
from collections import Counter
from pathlib import Path

from runners.ollama_client import OllamaClient

REASONER_PROMPT = Path("prompts/multi_agent_reasoner.txt").read_text() \
    if Path("prompts/multi_agent_reasoner.txt").exists() else "##question##"
VALIDATOR_PROMPT = Path("prompts/multi_agent_validator.txt").read_text() \
    if Path("prompts/multi_agent_validator.txt").exists() else "##question##"


def parse_reasoner(raw: str) -> tuple[str, str]:
    """Extract (final_answer, justification) from a reasoner JSON response."""
    try:
        body = raw
        if "```" in body:
            body = body.split("```")[1]
            if body.startswith("json"):
                body = body[4:]
        d = json.loads(body)
        ans = (d.get("final_answer") or "").strip().upper()
        if ans not in {"YES", "NO"}:
            ans = "PARSE_FAIL"
        return ans, d.get("reason", "")
    except Exception:
        return "PARSE_FAIL", ""


def run_one_item(client, model, question, *, A, tau_c, R, V, T, seed) -> dict:
    """Run the multi-agent debate on a single question and return a transcript."""
    decoding = {
        "temperature": T, "top_p": 0.9, "top_k": 40,
        "num_predict": 7900, "seed": seed,
    }
    conversation = []
    feedback = [""] * A         # validator feedback per reasoner

    for j in range(1, R + 1):
        round_answers = []
        for i in range(A):
            prompt = (REASONER_PROMPT
                      .replace("##question##", question)
                      .replace("##validator_feedback##", feedback[i])
                      .replace("{role_id}", str(i + 1)))
            resp = client.generate(model, prompt, options=decoding)
            ans, reason = parse_reasoner(resp["response"])
            round_answers.append(ans)
            conversation.append({
                "agent": f"R{i+1}",
                "round": j,
                "raw_response": resp["response"],
                "predicted": ans,
                "input_tokens": resp.get("prompt_eval_count"),
                "output_tokens": resp.get("eval_count"),
            })

        counts = Counter(a for a in round_answers if a in {"YES", "NO"})
        if counts:
            top, top_count = counts.most_common(1)[0]
            if top_count / max(1, sum(counts.values())) >= tau_c:
                return {
                    "final_answer": top,
                    "rounds_used": j,
                    "votes": dict(counts),
                    "decided_by": "consensus",
                    "conversation": conversation,
                }

        if V == "on" and j < R:
            v_prompt = (VALIDATOR_PROMPT
                        .replace("##question##", question)
                        .replace("##reasoner_outputs##",
                                 json.dumps(round_answers)))
            v_resp = client.generate(model, v_prompt, options=decoding)
            try:
                v_body = v_resp["response"]
                if "```" in v_body:
                    v_body = v_body.split("```")[1]
                    if v_body.startswith("json"):
                        v_body = v_body[4:]
                v_obj = json.loads(v_body)
                # Map issues back to per-reasoner feedback strings
                feedback = [""] * A
                for issue in v_obj.get("issues", []):
                    target = issue.get("reasoner", "")
                    if target.startswith("R") and target[1:].isdigit():
                        idx = int(target[1:]) - 1
                        if 0 <= idx < A:
                            feedback[idx] += (
                                f"[{issue.get('type','')}] "
                                f"{issue.get('description','')} "
                                f"-> {issue.get('suggested_fix','')}\n"
                            )
                conversation.append({
                    "agent": "V",
                    "round": j,
                    "raw_response": v_resp["response"],
                    "input_tokens": v_resp.get("prompt_eval_count"),
                    "output_tokens": v_resp.get("eval_count"),
                })
            except Exception:
                feedback = [""] * A   # validator parse failure: no feedback

    # Timeout: return plurality of last round
    final_counts = Counter(a for a in round_answers if a in {"YES", "NO"})
    top = final_counts.most_common(1)[0][0] if final_counts else "PARSE_FAIL"
    return {
        "final_answer": top,
        "rounds_used": R,
        "votes": dict(final_counts),
        "decided_by": "timeout_plurality",
        "conversation": conversation,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--benchmark", choices=["cladder", "corr2cause"], required=True)
    ap.add_argument("--ids", type=Path, required=True)
    ap.add_argument("--benchmark-source", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--A", type=int, default=3)
    ap.add_argument("--tau_c", type=float, default=0.9)
    ap.add_argument("--R", type=int, default=4)
    ap.add_argument("--V", choices=["on", "off"], default="on")
    ap.add_argument("--T", type=float, default=0.7)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    ids = set(json.loads(args.ids.read_text())["ids"])
    items = _load_items(args.benchmark, args.benchmark_source, ids)
    client = OllamaClient()

    for item_id, question, gt in items:
        out_file = args.out / f"{item_id}.json"
        if out_file.exists():
            continue
        t0 = time.perf_counter()
        result = run_one_item(client, args.model, question,
                               A=args.A, tau_c=args.tau_c, R=args.R,
                               V=args.V, T=args.T, seed=args.seed)
        result.update({
            "item_id": item_id, "question": question, "ground_truth": gt,
            "latency_seconds": time.perf_counter() - t0,
            "config": f"A{args.A}_T{args.T}_R{args.R}_V{args.V}",
            "model": args.model,
        })
        out_file.write_text(json.dumps(result, indent=2))


def _load_items(benchmark, source, id_set):
    # See runners/single_agent.py for the exact equivalent of this function.
    from runners.single_agent import _load_items as _impl
    yield from _impl(benchmark, source, id_set)


if __name__ == "__main__":
    main()
