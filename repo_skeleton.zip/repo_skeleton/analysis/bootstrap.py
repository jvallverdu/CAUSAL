"""Bootstrap CIs for raw accuracies (Table 10).

Computes BCa 95% bootstrap CIs over items for each (model, benchmark,
strategy) cell with at least 100 valid items.
"""
from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.stats import norm


def bca_ci(corrects: np.ndarray, B: int = 10000, alpha: float = 0.05,
           rng: np.random.Generator | None = None) -> tuple[float, float, float]:
    rng = rng or np.random.default_rng(42)
    n = len(corrects)
    theta_hat = corrects.mean()
    boots = np.empty(B)
    for i in range(B):
        boots[i] = corrects[rng.integers(0, n, size=n)].mean()

    # Bias correction
    z0 = norm.ppf(((boots < theta_hat).sum() + 0.5 * (boots == theta_hat).sum()) / B)
    if not np.isfinite(z0):
        z0 = 0.0

    # Acceleration via jackknife
    jack = np.empty(n)
    for j in range(n):
        jack[j] = np.delete(corrects, j).mean()
    jack_mean = jack.mean()
    num = ((jack_mean - jack) ** 3).sum()
    den = 6 * (((jack_mean - jack) ** 2).sum() ** 1.5)
    a = num / den if den > 0 else 0.0

    z_lo, z_hi = norm.ppf(alpha / 2), norm.ppf(1 - alpha / 2)
    a_lo = norm.cdf(z0 + (z0 + z_lo) / (1 - a * (z0 + z_lo)))
    a_hi = norm.cdf(z0 + (z0 + z_hi) / (1 - a * (z0 + z_hi)))
    lo = np.quantile(boots, a_lo)
    hi = np.quantile(boots, a_hi)
    return theta_hat, lo, hi


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--per-item-csv", type=Path,
                    default=Path("analysis/_built/per_item.csv"))
    ap.add_argument("--resamples", type=int, default=10000)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()

    table = defaultdict(list)
    with open(args.per_item_csv, newline="") as f:
        for row in csv.DictReader(f):
            if row["predicted"] not in {"YES", "NO"}:
                continue
            key = (row["model"], row["benchmark"], row["strategy"])
            table[key].append(int(row["predicted"] == row["ground_truth"]))

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with open(args.out, "w") as f:
        for (model, bench, strat), corrects in sorted(table.items()):
            if len(corrects) < 100:
                continue
            arr = np.array(corrects, dtype=float)
            mean, lo, hi = bca_ci(arr, B=args.resamples)
            f.write(f"{model} & {strat} & {mean*100:.1f} & "
                    f"[{lo*100:.1f},\\,{hi*100:.1f}] & {len(corrects)} \\\\\n")
    print(f"[OK] {args.out}")


if __name__ == "__main__":
    main()
