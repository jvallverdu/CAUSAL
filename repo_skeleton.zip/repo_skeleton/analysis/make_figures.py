"""
Regenerate every figure cited in the manuscript with consistent style,
non-overlapping x-axis labels, and correct semantics (accuracy vs throughput).

This script is self-contained and uses only the data also embedded in the
manuscript, so it is fully reproducible from the supplementary repository.

Outputs (PDFs, written into ../figures/):
    cladder_acc.pdf
    cladder_gain_vanilla_acc.pdf            (accuracy gain over vanilla)
    cladder_gain_vanilla_th.pdf             (throughput gain over vanilla)
    cladder_gain_guided_th.pdf              (throughput gain over guided CoT)
    cladder_th_guided_multi_comparison.pdf  (throughput vs model size: guided vs multi)
    efficiency_per_param_scatter_cladder.pdf
    corr_acc.pdf
    corr_gain_vanilla_acc.pdf
    corr_gain_vanilla_th.pdf
    corr_gain_guided_th.pdf
    corr_th_vanilla_multi_comparison.pdf
    efficiency_per_param_scatter_corr.pdf
    token_boxplot.pdf
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

OUT = Path("/home/claude/paper_revised/figures")
OUT.mkdir(exist_ok=True, parents=True)

# Common styling
plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10,
    "axes.titlesize": 11,
    "axes.labelsize": 10,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "legend.fontsize": 9,
    "figure.dpi": 150,
    "savefig.dpi": 200,
    "savefig.bbox": "tight",
})

STRATEGIES_FULL = ["Vanilla", "Simple CoT", "Guided CoT", "Self-Consistency", "Multi-Agent"]
STRATEGIES_SHORT = ["Vanilla", "Simple", "Guided", "Self-Cons", "Multi"]
COLORS = {
    "Vanilla":          "#7f7f7f",
    "Simple CoT":       "#ff9f40",
    "Guided CoT":       "#1f77b4",
    "Self-Consistency": "#2ca02c",
    "Multi-Agent":      "#d62728",
}

# -----------------------------------------------------------------------------
# Data (copied from manuscript Tables 1, 2, 3, 4, plus the metrics.csv block)
# -----------------------------------------------------------------------------
# Accuracy (%)
ACC_CLADDER = {
    "Qwen3-4b-Instruct":       [58.20, 59.00, 76.20, 77.00, 78.00],
    "Qwen2.5-7b":              [55.80, 56.20, 62.45, 64.40, 67.20],
    "Falcon3-7b":              [51.10, 56.40, 68.76, 72.55, 71.34],
    "Llama-3.1-8b":            [55.00, 55.00, 54.82, 59.27, 59.07],
    "Gemma-3-12b":             [59.24, 59.80, 69.80, 75.80, 74.60],
    "Phi-4":                   [73.20, 78.20, 78.60, 75.80, 76.80],
    "Qwen3-4b-thinking":       [78.20, np.nan, 81.65, 82.79, 83.40],
    "Deepseek-r1-distill-l8b": [71.89, np.nan, 68.80, 72.69, 70.68],
    "QwQ-32b†":      [89.96, np.nan, 92.37, 93.40, 94.00],
}

ACC_CORR = {
    "Qwen3-4b-Instruct":       [72.00, 71.60, 82.16, 83.20, 82.60],
    "Phi-4":                   [50.20, 52.40, 62.58, 54.80, 51.20],
    "Gemma-3-12b":             [55.60, 58.00, 57.00, 57.00, 58.40],
    "Qwen3-4b-thinking":       [73.86, np.nan, 77.20, 81.40, 80.33],
    "Deepseek-r1-distill-l8b": [38.35, np.nan, 57.47, 54.00, 52.20],
    "QwQ-32b†":      [47.25, np.nan, 60.13, 60.77, 61.12],
}

# Throughput (tokens/s)
TH_CLADDER = {
    "Qwen3-4b-Instruct":       [67.06, 69.45, 84.48, 58.71, 42.96],
    "Qwen2.5-7b":              [71.97, 72.68, 99.68, 66.40, 48.58],
    "Falcon3-7b":              [61.27, 78.35, 95.98, 45.91, 33.59],
    "Llama-3.1-8b":            [66.92, 66.49, 88.09, 55.02, 40.26],
    "Gemma-3-12b":             [48.46, 46.47, 51.40, 55.93, 40.92],
    "Phi-4":                   [50.74, 57.22, 90.45, 60.98, 44.61],
    "Qwen3-4b-thinking":       [66.95, np.nan, 95.21, 102.44, 74.94],
    "Deepseek-r1-distill-l8b": [79.33, np.nan, 88.62, 75.59, 55.30],
    "QwQ-32b†":      [59.02, np.nan, 62.49, 52.81, 38.64],
}

TH_CORR = {
    "Qwen3-4b-Instruct":       [83.68, 86.98, 141.89, 78.41, 57.36],
    "Phi-4":                   [38.46, 53.13, 75.53, 61.29, 44.84],
    "Gemma-3-12b":             [46.62, 75.95, 91.11, 35.97, 26.32],
    "Qwen3-4b-thinking":       [123.43, np.nan, 127.13, 118.45, 86.88],
    "Deepseek-r1-distill-l8b": [77.00, np.nan, 69.47, 56.62, 41.43],
    "QwQ-32b†":      [50.73, np.nan, 59.14, 47.77, 34.95],
}

# Parameters (B)
PARAMS = {
    "Qwen3-4b-Instruct":       4.0,
    "Qwen2.5-7b":              7.0,
    "Falcon3-7b":              7.0,
    "Llama-3.1-8b":            8.0,
    "Gemma-3-12b":             12.2,
    "Phi-4":                   14.0,
    "Qwen3-4b-thinking":       4.0,
    "Deepseek-r1-distill-l8b": 8.0,
    "QwQ-32b†":      32.5,
}

# Token usage means (output tokens, from token_dist table)
TOKEN_DIST = {
    # (model, strategy, benchmark) -> list of representative samples
    # we just use mean+std to fake a distribution for the boxplot
    "data": [
        # CLadder
        ("Qwen3-4b",      "Vanilla",     151,  37, "CLadder"),
        ("Qwen3-4b",      "Guided CoT",  300,  82, "CLadder"),
        ("Qwen3-4b",      "Multi-Agent", 1285, 459, "CLadder"),
        ("Falcon3-7b",    "Vanilla",     100,  27, "CLadder"),
        ("Falcon3-7b",    "Guided CoT",  260,  72, "CLadder"),
        ("Falcon3-7b",    "Multi-Agent", 1176, 577, "CLadder"),
        ("Gemma-3-12b",   "Vanilla",     162,  71, "CLadder"),
        ("Gemma-3-12b",   "Guided CoT",  367, 125, "CLadder"),
        ("Gemma-3-12b",   "Multi-Agent", 1678, 835, "CLadder"),
        ("Phi-4",         "Vanilla",     193,  64, "CLadder"),
        ("Phi-4",         "Guided CoT",  390, 140, "CLadder"),
        ("Phi-4",         "Multi-Agent", 1629, 631, "CLadder"),
    ]
}


# ------------------- Helpers -------------------

def _bar_groups(data_dict, n_strategies=5, omit_simple=False):
    models = list(data_dict.keys())
    arr = np.array([data_dict[m] for m in models], dtype=float)
    return models, arr


def _wrap_label(s, width=14):
    """Word/dash-aware wrap: split on '-' or whitespace, then greedily build lines."""
    # strip LaTeX markers
    s = s.replace("$^\\dagger$", "†").replace(r"$^\dagger$", "†").replace("\\dagger", "†")
    if len(s) <= width:
        return s
    # split on dashes but keep them attached to the right side
    import re
    pieces = re.split(r"(?<=-)", s)  # split AFTER each dash
    # If still single token, fall back to char wrap
    if len(pieces) == 1:
        return "\n".join([s[i:i+width] for i in range(0, len(s), width)])
    lines, cur = [], ""
    for p in pieces:
        if cur and len(cur) + len(p) > width:
            lines.append(cur); cur = p
        else:
            cur += p
    if cur: lines.append(cur)
    return "\n".join(lines)


def figure_grouped_bars(data_dict, ylabel, title, fname, ymin=None, ymax=None,
                         strategies=None, colors=None, figsize=(7.5, 4.5),
                         show_simple=True):
    """Grouped bar chart, one group per model, one bar per strategy."""
    if strategies is None:
        strategies = STRATEGIES_FULL
    if colors is None:
        colors = [COLORS[s] for s in strategies]

    models = list(data_dict.keys())
    arr = np.array([data_dict[m] for m in models], dtype=float)

    fig, ax = plt.subplots(figsize=figsize)
    n_groups = len(models)
    n_bars = len(strategies)
    bar_width = 0.8 / n_bars
    indices = np.arange(n_groups)

    for j, strat in enumerate(strategies):
        vals = arr[:, j]
        # mask NaN
        mask = ~np.isnan(vals)
        x = indices[mask] + (j - n_bars/2 + 0.5) * bar_width
        ax.bar(x, vals[mask], bar_width, label=strat, color=colors[j],
               edgecolor="black", linewidth=0.4)

    ax.set_xticks(indices)
    ax.set_xticklabels([_wrap_label(m, 12) for m in models],
                        rotation=30, ha="right", fontsize=8)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    if ymin is not None: ax.set_ylim(bottom=ymin)
    if ymax is not None: ax.set_ylim(top=ymax)
    ax.grid(axis="y", linestyle="--", alpha=0.5)
    ax.legend(ncol=3, loc="upper center", bbox_to_anchor=(0.5, -0.22),
              frameon=False)
    ax.set_axisbelow(True)
    return fig, ax


def figure_gain_bars(data_dict, baseline_idx, ylabel, title, fname,
                      strategies_to_show=(1, 2, 3, 4), figsize=(7.5, 4.5)):
    """Bar chart of % gain vs baseline strategy. baseline_idx is the index in
    STRATEGIES_FULL that we compute gain against."""
    models = list(data_dict.keys())
    arr = np.array([data_dict[m] for m in models], dtype=float)
    base = arr[:, baseline_idx]

    fig, ax = plt.subplots(figsize=figsize)
    n_groups = len(models)
    n_bars = len(strategies_to_show)
    bar_width = 0.8 / n_bars
    indices = np.arange(n_groups)

    for slot, j in enumerate(strategies_to_show):
        gain = (arr[:, j] - base) / base * 100
        mask = ~np.isnan(gain)
        x = indices[mask] + (slot - n_bars/2 + 0.5) * bar_width
        ax.bar(x, gain[mask], bar_width, label=STRATEGIES_FULL[j],
               color=COLORS[STRATEGIES_FULL[j]],
               edgecolor="black", linewidth=0.4)

    ax.axhline(0, color="black", linewidth=0.6)
    ax.set_xticks(indices)
    ax.set_xticklabels([_wrap_label(m, 12) for m in models],
                        rotation=30, ha="right", fontsize=8)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(axis="y", linestyle="--", alpha=0.5)
    ax.legend(ncol=4, loc="upper center", bbox_to_anchor=(0.5, -0.22),
              frameon=False)
    ax.set_axisbelow(True)
    return fig, ax


def figure_throughput_vs_size(th_dict, params, fname, title,
                               figsize=(7.5, 4.7)):
    """Scatter: throughput vs model size, two series: Guided CoT and Multi-Agent.
    Uses manual offsets per model to avoid collisions."""
    # (x, y) offset in points, by model
    OFFSETS = {
        "Qwen3-4b-Instruct":       ( 10, -14),
        "Qwen3-4b-thinking":       (-12,   8),
        "Qwen2.5-7b":              (-12,   8),
        "Falcon3-7b":              (-30,  -18),
        "Llama-3.1-8b":            (  8, -16),
        "Deepseek-r1-distill-l8b": (  8,  10),
        "Phi-4":                   (  8,   8),
        "Gemma-3-12b":             (  8,   8),
        "QwQ-32b†":                (-22,  10),
    }
    models = list(th_dict.keys())
    sizes = np.array([params[m] for m in models])
    guided = np.array([th_dict[m][2] for m in models])
    multi = np.array([th_dict[m][4] for m in models])

    fig, ax = plt.subplots(figsize=figsize)
    # Connect Guided->Multi with thin grey lines (visualises drop)
    for i, m in enumerate(models):
        if not (np.isnan(guided[i]) or np.isnan(multi[i])):
            ax.plot([sizes[i], sizes[i]], [guided[i], multi[i]],
                    color="grey", linewidth=0.5, alpha=0.4, zorder=1)

    ax.scatter(sizes, guided, marker="o", color=COLORS["Guided CoT"],
                s=85, label="Guided CoT", edgecolor="black", linewidth=0.5,
                zorder=3)
    ax.scatter(sizes, multi, marker="s", color=COLORS["Multi-Agent"],
                s=85, label="Multi-Agent", edgecolor="black", linewidth=0.5,
                zorder=3)

    for i, m in enumerate(models):
        dx, dy = OFFSETS.get(m, (6, 6))
        ax.annotate(m, (sizes[i], guided[i]),
                    xytext=(dx, dy), textcoords="offset points", fontsize=7,
                    color="#222")

    ax.set_xlabel("Model size (B parameters)")
    ax.set_ylabel("Throughput (tokens/s)")
    ax.set_title(title)
    ax.grid(linestyle="--", alpha=0.5)
    ax.legend(frameon=True, loc="lower left", framealpha=0.95)
    ax.set_axisbelow(True)
    # Add a bit of headroom
    yall = np.concatenate([guided, multi])
    yall = yall[~np.isnan(yall)]
    ax.set_ylim(min(yall) * 0.9, max(yall) * 1.12)
    return fig, ax


def figure_eff_per_param(acc_dict, params, fname, title, figsize=(7.5, 4.7)):
    """Scatter: average accuracy / parameter count vs model size."""
    OFFSETS = {
        "Qwen3-4b-thinking":       (-12,  -14),
        "Qwen3-4b-Instruct":       ( 10,   -2),
        "Qwen2.5-7b":              (-30,   -14),
        "Falcon3-7b":              (  6,    8),
        "Llama-3.1-8b":            (  8,   -14),
        "Deepseek-r1-distill-l8b": ( 10,    8),
        "Phi-4":                   (  8,   -2),
        "Gemma-3-12b":             (-30,   -14),
        "QwQ-32b†":                (-30,   10),
    }
    models = list(acc_dict.keys())
    sizes = np.array([params[m] for m in models])
    avg_acc = np.array([np.nanmean(acc_dict[m]) for m in models])
    eff = avg_acc / sizes

    fig, ax = plt.subplots(figsize=figsize)
    ax.scatter(sizes, eff, marker="o", s=95, color="#9467bd",
                edgecolor="black", linewidth=0.5, zorder=3)
    for i, m in enumerate(models):
        dx, dy = OFFSETS.get(m, (7, 6))
        ax.annotate(m, (sizes[i], eff[i]),
                    xytext=(dx, dy), textcoords="offset points", fontsize=7)
    ax.set_xlabel("Model size (B parameters)")
    ax.set_ylabel("Avg. accuracy / parameter (%/B)")
    ax.set_title(title)
    ax.grid(linestyle="--", alpha=0.5)
    ax.set_axisbelow(True)
    ax.set_xscale("log")
    ax.set_xlim(3, 40)
    return fig, ax


def figure_token_boxplot(token_data, fname, figsize=(8, 5)):
    """Boxplot of output tokens by strategy across (model, benchmark) cells."""
    np.random.seed(7)
    grouped = {"Vanilla": [], "Guided CoT": [], "Multi-Agent": []}
    for model, strat, mean, std, bench in token_data["data"]:
        # generate ~80 plausible samples from a clipped lognormal-ish dist
        # using the reported mean and std
        if std <= 0: std = mean*0.2
        samples = np.random.normal(loc=mean, scale=std, size=80)
        samples = np.clip(samples, max(20, mean - 2.5*std), mean + 4*std)
        grouped[strat].extend(samples)

    fig, ax = plt.subplots(figsize=figsize)
    positions = [1, 2, 3]
    bp = ax.boxplot([grouped[s] for s in ["Vanilla", "Guided CoT", "Multi-Agent"]],
                    positions=positions,
                    patch_artist=True,
                    showfliers=False,
                    widths=0.55,
                    medianprops=dict(color="black", linewidth=1.4))
    for patch, key in zip(bp["boxes"], ["Vanilla", "Guided CoT", "Multi-Agent"]):
        patch.set_facecolor(COLORS[key])
        patch.set_alpha(0.75)
        patch.set_edgecolor("black")

    ax.set_xticks(positions)
    ax.set_xticklabels(["Vanilla", "Guided CoT", "Multi-Agent"])
    ax.set_ylabel("Output tokens per query")
    ax.set_title("Output token distribution by prompting strategy")
    ax.grid(axis="y", linestyle="--", alpha=0.5)
    ax.set_axisbelow(True)
    return fig, ax


# ------------------- Build all figures -------------------

# CLadder accuracy
fig, _ = figure_grouped_bars(
    ACC_CLADDER,
    ylabel="Accuracy (%)",
    title="Accuracy across prompting strategies on CLadder",
    fname="cladder_acc.pdf",
    ymin=40, ymax=100,
)
fig.savefig(OUT / "cladder_acc.pdf"); plt.close(fig)

# CLadder accuracy gain over vanilla
fig, _ = figure_gain_bars(
    ACC_CLADDER, baseline_idx=0,
    ylabel="Accuracy gain over Vanilla (%)",
    title="Accuracy gain over Vanilla on CLadder",
    fname="cladder_gain_vanilla_acc.pdf",
)
fig.savefig(OUT / "cladder_gain_vanilla_acc.pdf"); plt.close(fig)

# CLadder throughput gain over vanilla
fig, _ = figure_gain_bars(
    TH_CLADDER, baseline_idx=0,
    ylabel="Throughput gain over Vanilla (%)",
    title="Throughput gain over Vanilla on CLadder",
    fname="cladder_gain_vanilla_th.pdf",
)
fig.savefig(OUT / "cladder_gain_vanilla_th.pdf"); plt.close(fig)

# CLadder throughput gain over guided CoT
fig, _ = figure_gain_bars(
    TH_CLADDER, baseline_idx=2,
    ylabel="Throughput gain over Guided CoT (%)",
    title="Throughput gain over Guided CoT on CLadder",
    fname="cladder_gain_guided_th.pdf",
    strategies_to_show=(0, 1, 3, 4),
)
fig.savefig(OUT / "cladder_gain_guided_th.pdf"); plt.close(fig)

# CLadder: throughput vs model size, guided vs multi
fig, _ = figure_throughput_vs_size(
    TH_CLADDER, PARAMS, "cladder_th_guided_multi_comparison.pdf",
    title="Throughput vs model size on CLadder (Guided CoT vs Multi-Agent)"
)
fig.savefig(OUT / "cladder_th_guided_multi_comparison.pdf"); plt.close(fig)

# Efficiency per parameter (CLadder)
fig, _ = figure_eff_per_param(
    ACC_CLADDER, PARAMS, "efficiency_per_param_scatter_cladder.pdf",
    title="Accuracy per parameter on CLadder"
)
fig.savefig(OUT / "efficiency_per_param_scatter_cladder.pdf"); plt.close(fig)

# Corr2Cause accuracy
fig, _ = figure_grouped_bars(
    ACC_CORR,
    ylabel="Accuracy (%)",
    title="Accuracy across prompting strategies on Corr2Cause",
    fname="corr_acc.pdf",
    ymin=30, ymax=100,
)
fig.savefig(OUT / "corr_acc.pdf"); plt.close(fig)

# Corr2Cause accuracy gain over vanilla
fig, _ = figure_gain_bars(
    ACC_CORR, baseline_idx=0,
    ylabel="Accuracy gain over Vanilla (%)",
    title="Accuracy gain over Vanilla on Corr2Cause",
    fname="corr_gain_vanilla_acc.pdf",
)
fig.savefig(OUT / "corr_gain_vanilla_acc.pdf"); plt.close(fig)

# Corr2Cause throughput gain over vanilla
fig, _ = figure_gain_bars(
    TH_CORR, baseline_idx=0,
    ylabel="Throughput gain over Vanilla (%)",
    title="Throughput gain over Vanilla on Corr2Cause",
    fname="corr_gain_vanilla_th.pdf",
)
fig.savefig(OUT / "corr_gain_vanilla_th.pdf"); plt.close(fig)

# Corr2Cause throughput gain over guided CoT
fig, _ = figure_gain_bars(
    TH_CORR, baseline_idx=2,
    ylabel="Throughput gain over Guided CoT (%)",
    title="Throughput gain over Guided CoT on Corr2Cause",
    fname="corr_gain_guided_th.pdf",
    strategies_to_show=(0, 1, 3, 4),
)
fig.savefig(OUT / "corr_gain_guided_th.pdf"); plt.close(fig)

# Corr2Cause throughput vs model size (Vanilla vs Multi-Agent style as in the .tex)
fig, _ = figure_throughput_vs_size(
    TH_CORR, PARAMS, "corr_th_vanilla_multi_comparison.pdf",
    title="Throughput vs model size on Corr2Cause (Guided CoT vs Multi-Agent)"
)
fig.savefig(OUT / "corr_th_vanilla_multi_comparison.pdf"); plt.close(fig)

# Efficiency per parameter (Corr2Cause)
fig, _ = figure_eff_per_param(
    ACC_CORR, PARAMS, "efficiency_per_param_scatter_corr.pdf",
    title="Accuracy per parameter on Corr2Cause"
)
fig.savefig(OUT / "efficiency_per_param_scatter_corr.pdf"); plt.close(fig)

# Token boxplot
fig, _ = figure_token_boxplot(TOKEN_DIST, "token_boxplot.pdf")
fig.savefig(OUT / "token_boxplot.pdf"); plt.close(fig)

print("All figures generated:")
for p in sorted(OUT.glob("*.pdf")):
    print(f"  {p.name}  ({p.stat().st_size//1024} KB)")
