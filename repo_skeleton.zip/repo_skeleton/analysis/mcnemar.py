"""Per-pair McNemar tests with Benjamini-Hochberg FDR correction.

Generates Table 9 of the paper from the per-item CSV produced by
`eval/score.py`. For each (model, benchmark) pair, compares multi-agent
against the best single-agent strategy (the one with the highest accuracy
on that pair), computes:

  * b = items correct only under multi-agent
  * c = items correct only under best single-agent
  * McNemar's continuity-corrected chi^2
  * Two-sided p-value
  * Benjamini-Hochberg adjusted p-value (FDR q=0.10 by default)
  * Cliff's delta = (b - c) / n
  * Wald 95% CI for the accuracy delta

Outputs both a CSV (for programmatic use) and a LaTeX table (for the paper).
"""
from __future__ import annotations

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.stats import chi2, norm


def mcnemar(b: int, c: int) -> tuple[float, float]:
    if b + c == 0:
        return 0.0, 1.0
    stat = (abs(b - c) - 1) ** 2 / (b + c)
    p = 1 - chi2.cdf(stat, df=1)
    return stat, p


def acc_delta_ci(b: int, c: int, n: int, alpha: float = 0.05) -> tuple[float, float, float]:
    diff = (b - c) / n
    var = ((b + c) - (b - c) ** 2 / n) / n ** 2
    se = math.sqrt(max(var, 1e-12))
    z = norm.ppf(1 - alpha / 2)
    return diff, diff - z * se, diff + z * se


def bh_adjust(pvals: list[float], alpha: float = 0.10) -> tuple[np.ndarray, np.ndarray]:
    pvals = np.asarray(pvals, dtype=float)
    n = len(pvals)
    order = np.argsort(pvals)
    ranked = pvals[order]
    adj = np.empty(n)
    prev = 1.0
    for i in range(n - 1, -1, -1):
        prev = min(prev, ranked[i] * n / (i + 1))
        adj[i] = min(prev, 1.0)
    out_adj = np.empty(n)
    out_adj[order] = adj
    return out_adj, out_adj < alpha


def load_per_item(csv_path: Path) -> dict:
    """Returns dict[(model, benchmark, strategy)] -> dict[item_id] -> bool correct."""
    table = defaultdict(dict)
    with open(csv_path, newline="") as f:
        for row in csv.DictReader(f):
            if row["predicted"] not in {"YES", "NO"}:
                continue
            key = (row["model"], row["benchmark"], row["strategy"])
            table[key][row["item_id"]] = (row["predicted"] == row["ground_truth"])
    return table


def find_best_single_agent(table, model, benchmark) -> tuple[str, float]:
    best, best_acc = None, -1.0
    for strat in ("vanilla", "simple_cot", "guided_cot", "self_consistency"):
        key = (model, benchmark, strat)
        if key in table:
            acc = sum(table[key].values()) / max(1, len(table[key]))
            if acc > best_acc:
                best, best_acc = strat, acc
    return best, best_acc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--per-item-csv", type=Path,
                    default=Path("analysis/_built/per_item.csv"))
    ap.add_argument("--apply-bh", action="store_true")
    ap.add_argument("--q", type=float, default=0.10)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()

    table = load_per_item(args.per_item_csv)
    rows = []
    pvals = []
    for (model, bench, strat), per_item in sorted(table.items()):
        if strat != "multi_agent":
            continue
        best_strat, _ = find_best_single_agent(table, model, bench)
        if best_strat is None:
            continue
        ma = per_item
        sa = table.get((model, bench, best_strat), {})
        common = sorted(set(ma.keys()) & set(sa.keys()))
        b = sum(1 for i in common if ma[i] and not sa[i])
        c = sum(1 for i in common if sa[i] and not ma[i])
        n = len(common)
        chi2_stat, p = mcnemar(b, c)
        delta, lo, hi = acc_delta_ci(b, c, n)
        rows.append({
            "model": model, "benchmark": bench, "best_single": best_strat,
            "n": n, "b": b, "c": c, "chi2": chi2_stat, "p_raw": p,
            "delta_pct": delta * 100, "ci_lo_pct": lo * 100, "ci_hi_pct": hi * 100,
            "cliffs_d": (b - c) / n,
        })
        pvals.append(p)

    if args.apply_bh:
        adj, sig = bh_adjust(pvals, args.q)
        for r, a, s in zip(rows, adj, sig):
            r["p_adj"] = float(a)
            r["sig_bh"] = bool(s)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    csv_out = args.out.with_suffix(".csv")
    with open(csv_out, "w", newline="") as f:
        if rows:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)

    # LaTeX
    with open(args.out, "w") as f:
        for r in rows:
            mark = r"$\,\mathbf{*}$" if r.get("sig_bh") else ""
            p_adj_str = (f"$<\\!10^{{-4}}$" if r.get("p_adj", 1) < 1e-4
                          else f"{r.get('p_adj', float('nan')):.3f}")
            f.write(f"{r['model']} & {r['benchmark']} & {r['best_single']} & "
                    f"{r['delta_pct']:+.2f} & "
                    f"[{r['ci_lo_pct']:+.2f},\\,{r['ci_hi_pct']:+.2f}] & "
                    f"{r['b']} & {r['c']} & {r['n']} & "
                    f"{r['chi2']:.2f} & {r['p_raw']:.3f} & "
                    f"{p_adj_str}{mark} & ${r['cliffs_d']:+.3f}$ \\\\\n")
    print(f"[OK] {args.out} ({len(rows)} comparisons)")


if __name__ == "__main__":
    main()
