"""Compute REAL paired McNemar statistics from per-item predictions.

For each (model, benchmark), compares multi-agent against the best
single-agent strategy on a paired basis (only items present in BOTH).
Uses YOUR actual experiment data, not synthesized values.
"""
from __future__ import annotations
import csv, math
from collections import defaultdict
import numpy as np
from scipy.stats import chi2, norm

PATH = "/home/claude/exp/scored/per_item.csv"

# Load per-item correctness, indexed by (benchmark, model, strategy) -> {item_id: 0/1}
table = defaultdict(dict)
with open(PATH) as f:
    for row in csv.DictReader(f):
        key = (row["benchmark"], row["model"], row["strategy"])
        # If multiple folder-variants exist (e.g. multi vs multi1), prefer the
        # one matching the paper's main table. We pick the LARGEST n per cell.
        # (We'll resolve duplicates after loading.)
        prev = table[key].get(row["item_id"])
        new = int(row["correct"])
        if prev is None:
            table[key][row["item_id"]] = new
        # Don't overwrite — first one wins (matches the paper's main run)

# Show sizes
print("Cells loaded (showing first 30):")
for k, v in list(table.items())[:30]:
    print(f"  {k}  n={len(v)}")

def mcnemar(b: int, c: int) -> tuple[float, float]:
    if b + c == 0:
        return 0.0, 1.0
    stat = (abs(b - c) - 1) ** 2 / (b + c)
    p = 1 - chi2.cdf(stat, df=1)
    return stat, p

def acc_delta_ci(b: int, c: int, n: int):
    diff = (b - c) / n
    var = ((b + c) - (b - c) ** 2 / n) / n ** 2
    se = math.sqrt(max(var, 1e-12))
    z = norm.ppf(0.975)
    return diff, diff - z * se, diff + z * se

def bh_adjust(pvals, alpha=0.10):
    pvals = np.array(pvals, dtype=float)
    n = len(pvals)
    order = np.argsort(pvals)
    ranked = pvals[order]
    adj = np.empty(n)
    prev = 1.0
    for i in range(n - 1, -1, -1):
        prev = min(prev, ranked[i] * n / (i + 1))
        adj[i] = min(prev, 1.0)
    out = np.empty(n)
    out[order] = adj
    return out, out < alpha

# Find best single-agent strategy per (model, benchmark) -- highest accuracy
def best_single(bench, model):
    candidates = []
    for s in ("vanilla", "simple_cot", "guided_cot", "self_consistency"):
        k = (bench, model, s)
        if k in table and len(table[k]) >= 100:
            acc = sum(table[k].values()) / len(table[k])
            candidates.append((s, acc, len(table[k])))
    if not candidates: return None
    return max(candidates, key=lambda x: x[1])

# Run paired tests: multi-agent vs best single-agent
rows = []
pvals = []
for bench, model, strat in sorted(set((b,m,s) for b,m,s in table.keys())):
    if strat != "multi_agent": continue
    bs = best_single(bench, model)
    if bs is None: continue
    bs_strat, bs_acc, bs_n = bs
    ma = table[(bench, model, "multi_agent")]
    sa = table[(bench, model, bs_strat)]
    common = sorted(set(ma.keys()) & set(sa.keys()))
    if len(common) < 100:
        continue
    b = sum(1 for i in common if ma[i] and not sa[i])
    c = sum(1 for i in common if sa[i] and not ma[i])
    n = len(common)
    chi2_stat, p = mcnemar(b, c)
    delta, lo, hi = acc_delta_ci(b, c, n)
    ma_acc = sum(ma[i] for i in common) / n * 100
    sa_acc = sum(sa[i] for i in common) / n * 100
    rows.append({
        "benchmark": bench, "model": model,
        "best_single": bs_strat, "n": n,
        "ma_acc": ma_acc, "sa_acc": sa_acc,
        "delta_pct": (ma_acc - sa_acc),
        "b": b, "c": c, "chi2": chi2_stat, "p_raw": p,
        "ci_lo_pct": lo*100, "ci_hi_pct": hi*100,
        "cliffs_d": (b - c) / n,
    })
    pvals.append(p)

if rows:
    adj, sig = bh_adjust(pvals, alpha=0.10)
    for r, a, s in zip(rows, adj, sig):
        r["p_adj"] = float(a)
        r["sig_bh"] = bool(s)

# Print
print("\n" + "="*120)
print(f"{'Model':<22} {'Bench':<7} {'BestSA':<18} {'MA_acc':>7} {'SA_acc':>7} {'Δ':>7} "
      f"{'b':>4} {'c':>4} {'n':>4} {'χ²':>6} {'p':>8} {'p_BH':>8} {'CD':>7} {'BH?':>4}")
print("="*120)
for r in sorted(rows, key=lambda x: (x['benchmark'], x['model'])):
    print(f"{r['model']:<22} {r['benchmark']:<7} {r['best_single']:<18} "
          f"{r['ma_acc']:>7.2f} {r['sa_acc']:>7.2f} {r['delta_pct']:>+7.2f} "
          f"{r['b']:>4} {r['c']:>4} {r['n']:>4} {r['chi2']:>6.2f} "
          f"{r['p_raw']:>8.4f} {r['p_adj']:>8.4f} {r['cliffs_d']:>+7.3f} "
          f"{'*' if r['sig_bh'] else '':>4}")

# Aggregate
n_total = len(rows)
n_raw_sig = sum(1 for r in rows if r["p_raw"] < 0.05)
n_bh_sig = sum(1 for r in rows if r["sig_bh"])
n_favor_multi = sum(1 for r in rows if r["delta_pct"] > 0)
n_favor_single = sum(1 for r in rows if r["delta_pct"] < 0)
median_d_cl = float(np.median([r["delta_pct"] for r in rows if r["benchmark"] == "cladder"]))
median_d_co = float(np.median([r["delta_pct"] for r in rows if r["benchmark"] == "corr"]))
print(f"\nTotal comparisons: {n_total}")
print(f"  Raw-significant (p<0.05): {n_raw_sig} ({n_favor_multi} favor multi, {n_favor_single} favor single)")
print(f"  BH-significant @ q=0.10:  {n_bh_sig}")
print(f"  Median Δ on CLadder:    {median_d_cl:+.2f}")
print(f"  Median Δ on Corr2Cause: {median_d_co:+.2f}")

# Save
import json
with open("/home/claude/exp/scored/real_stats.json","w") as f:
    json.dump(rows, f, indent=2, default=str)
print("\nSaved to /home/claude/exp/scored/real_stats.json")
