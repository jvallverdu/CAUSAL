"""Score every (model, strategy, benchmark) cell against ground truth.

Walks outputs/{cladder,corr}/<model>/<strategy>/, joins predictions to
ground-truth labels by item ID, and produces:
  - per_item.csv : flat table for downstream stats
  - summary.csv  : (benchmark, model, strategy) -> accuracy, n, parse_fail
"""
from __future__ import annotations
import csv, json, re
from pathlib import Path
from collections import defaultdict

ROOT = Path("/home/claude/exp/outputs")
GT_DIR = Path("/home/claude/data")

# -- Load ground truth ------------------------------------------------------
gt = {"cladder": {}, "corr": {}}

with open(GT_DIR / "cladder_500.csv", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        gt["cladder"][str(r["id"])] = r["label"].strip().lower()  # 'yes'/'no'

with open(GT_DIR / "corr_test.csv", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        # corr2cause uses 0/1 -> map to no/yes
        lab = str(r["label"]).strip()
        gt["corr"][str(r["id"])] = "yes" if lab == "1" else "no"

print(f"GT: cladder={len(gt['cladder'])}, corr={len(gt['corr'])}")

# -- Models / strategies we care about (ignore 'old', 'pcca', '*_old', etc.)
# Map your folder names to the canonical names from the paper
MODEL_MAP = {
    "qwen3":           "Qwen3-4b-Instruct",
    "qwen3_i":         "Qwen3-4b-Instruct",   # some folders use this name
    "qwen2.5":         "Qwen2.5-7b",
    "falcon":          "Falcon3-7b",
    "llama3.1":        "Llama-3.1-8b",
    "gemma":           "Gemma-3-12b",
    "phi4":            "Phi-4",
    "qwen3_thinking":  "Qwen3-4b-thinking",
    "deepseek_llama":  "Deepseek-r1-d-l8b",
    "deepseek":        "Deepseek-r1-d-l8b",
    "qwen32":          "QwQ-32b",
}
# Folder name -> strategy in the paper
STRATEGY_MAP = {
    "vanilla":          "vanilla",
    "simple_cot":       "simple_cot",
    "guided":           "guided_cot",
    "self":             "self_consistency",  # K=5 self-consistency
    "multi":            "multi_agent",
    "single":           "vanilla",   # qwen3_i/single is the qwen3-i vanilla run
    "multi1":           "multi_agent",   # qwen3_thinking/multi1 = the multi run referenced in paper
    "guided1":          "guided_cot",    # gemma/guided1 = the guided run referenced in paper
    "simple_cot1":      "simple_cot",
}

# -- Parse predictions ------------------------------------------------------
FILENAME_PRED = re.compile(r"_(\d+)_(YES|NO)\.json$", re.IGNORECASE)

def parse_pred_from_file(fp: Path) -> tuple[str | None, str | None]:
    """Return (item_id, predicted_label) where predicted_label is 'yes'/'no'/'parse_fail'."""
    # Try to read JSON first; fall back to filename
    try:
        d = json.load(open(fp, encoding="utf-8"))
    except Exception:
        d = {}

    # ID: try in JSON, then filename
    item_id = None
    if "id" in d:
        item_id = str(d["id"])
    else:
        m = FILENAME_PRED.search(fp.name)
        if m:
            item_id = m.group(1)

    # Predicted label
    pred_raw = (d.get("final_answer") or "").strip().lower()
    if pred_raw not in ("yes", "no"):
        # try parsed_json
        pj = d.get("parsed_json", {})
        if isinstance(pj, dict):
            pred_raw = (pj.get("final_answer") or "").strip().lower()
    if pred_raw not in ("yes", "no"):
        # fall back to filename
        m = FILENAME_PRED.search(fp.name)
        if m:
            pred_raw = m.group(2).lower()
    if pred_raw not in ("yes", "no"):
        pred_raw = "parse_fail"

    return item_id, pred_raw


# -- Score every cell --------------------------------------------------------
per_item_rows = []
summary = []

for bench_dir in sorted(ROOT.iterdir()):
    if not bench_dir.is_dir() or bench_dir.name not in ("cladder", "corr"):
        continue
    bench = bench_dir.name
    for model_dir in sorted(bench_dir.iterdir()):
        if not model_dir.is_dir():
            continue
        if model_dir.name not in MODEL_MAP:
            continue
        canonical_model = MODEL_MAP[model_dir.name]
        for strat_dir in sorted(model_dir.iterdir()):
            if not strat_dir.is_dir():
                continue
            if strat_dir.name not in STRATEGY_MAP:
                continue
            canonical_strat = STRATEGY_MAP[strat_dir.name]

            # Walk .json files DIRECTLY in this folder (skip 'old' subfolders)
            jsons = [f for f in strat_dir.glob("*.json")]
            if len(jsons) < 100:
                continue   # skip incomplete cells

            n = 0; correct = 0; parse_fail = 0
            for fp in jsons:
                item_id, pred = parse_pred_from_file(fp)
                if item_id is None or item_id not in gt[bench]:
                    continue
                n += 1
                if pred == "parse_fail":
                    parse_fail += 1
                    continue
                gt_label = gt[bench][item_id]
                ok = (pred == gt_label)
                if ok: correct += 1
                per_item_rows.append({
                    "benchmark": bench,
                    "model": canonical_model,
                    "model_folder": model_dir.name,
                    "strategy": canonical_strat,
                    "strategy_folder": strat_dir.name,
                    "item_id": item_id,
                    "predicted": pred,
                    "ground_truth": gt_label,
                    "correct": int(ok),
                })
            valid = n - parse_fail
            acc = correct / valid * 100 if valid else 0.0
            summary.append({
                "benchmark": bench,
                "model": canonical_model,
                "strategy": canonical_strat,
                "model_folder": model_dir.name,
                "strategy_folder": strat_dir.name,
                "n_total": n,
                "n_valid": valid,
                "n_correct": correct,
                "n_parse_fail": parse_fail,
                "accuracy_pct": round(acc, 2),
            })

# Write per-item CSV
out_dir = Path("/home/claude/exp/scored")
out_dir.mkdir(exist_ok=True)
with open(out_dir / "per_item.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(per_item_rows[0].keys()))
    w.writeheader(); w.writerows(per_item_rows)

# Write summary CSV
with open(out_dir / "summary.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(summary[0].keys()))
    w.writeheader(); w.writerows(summary)

# Print summary
print(f"\n{'Benchmark':<10} {'Model':<22} {'Strategy':<18} {'Folder':<12} {'n':>4} {'acc':>7}")
print("-" * 85)
for s in sorted(summary, key=lambda x: (x['benchmark'], x['model'], x['strategy'])):
    print(f"{s['benchmark']:<10} {s['model']:<22} {s['strategy']:<18} "
          f"{s['strategy_folder']:<12} {s['n_valid']:>4} {s['accuracy_pct']:>6.2f}%")

print(f"\nTotal cells scored: {len(summary)}")
print(f"Total per-item rows: {len(per_item_rows)}")
