"""Robust answer parsing.

Tries to recover a YES/NO answer from a model response in the following
priority order:
  1. Strict JSON parse, look for "final_answer" key.
  2. Loose JSON parse after stripping ``` fences.
  3. Regex fallback: last occurrence of YES or NO in the response.
"""
from __future__ import annotations

import json
import re

_FALLBACK_RE = re.compile(r"\b(YES|NO)\b", re.IGNORECASE)


def parse(raw: str) -> str:
    """Return one of {"YES", "NO", "PARSE_FAIL"}."""
    if not raw:
        return "PARSE_FAIL"

    # 1. Try strict JSON
    try:
        d = json.loads(raw)
        ans = (d.get("final_answer") or "").strip().upper()
        if ans in {"YES", "NO"}:
            return ans
    except Exception:
        pass

    # 2. Strip ```json ... ``` fences
    body = raw
    if "```" in body:
        try:
            chunk = body.split("```")[1]
            if chunk.startswith("json"):
                chunk = chunk[4:]
            d = json.loads(chunk)
            ans = (d.get("final_answer") or "").strip().upper()
            if ans in {"YES", "NO"}:
                return ans
        except Exception:
            pass

    # 3. Regex fallback (last match wins)
    matches = _FALLBACK_RE.findall(raw)
    if matches:
        return matches[-1].upper()

    return "PARSE_FAIL"
