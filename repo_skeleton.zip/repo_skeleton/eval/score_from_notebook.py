"""
Notebook conversion: results scoring pipeline used in the paper.

Extracted from results.ipynb. This is the actual code path used to:
  (1) walk every <benchmark>/<model>/<strategy>/ folder of multi-agent runs
  (2) extract the predicted label from each JSON
  (3) join against the source dataset by id
  (4) compute accuracy against ground truth.

Folder structure expected (from the previous engineer's setup):
    <project_root>/
        cladder/<model>/<strategy>/<timestamp>_<id>_<predicted_label>.json
        corr/<model>/<strategy>/<timestamp>_<id>_<predicted_label>.json
        data/CLadder/data/cladder_500.csv      (ground truth for CLadder)
        data/corr2cause/corr_test.csv          (ground truth for Corr2Cause)
"""
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any, Iterable, Tuple

def make_hashable(value: Any) -> Any:
    # Convert common unhashable types to hashable equivalents for counting
    if isinstance(value, list):
        return tuple(make_hashable(v) for v in value)
    if isinstance(value, dict):
        # Stable, order-independent representation
        return json.dumps(value, sort_keys=True, ensure_ascii=False)
    return value


def iter_json_files(root: Path, recursive: bool) -> Iterable[Path]:
    pattern = "**/*.json" if recursive else "*.json"
    yield from root.glob(pattern)

from pathlib import Path
from typing import List

def main(directory,path, recursive=False) -> Tuple[Counter, List[Path]]:
    # From a string
    root = Path(directory)/path  # Windows: use raw string or double backslashes

    if not root.exists() or not root.is_dir():
        raise SystemExit(f"Not a directory: {root}")

    counts: Counter = Counter()
    files_with_rounds_gt_1: List[Path] = []
    total_files = 0
    files_with_key = 0
    missing_key = 0
    parse_errors: list[Tuple[Path, str]] = []

    for file_path in iter_json_files(root, recursive):
        total_files += 1
        try:
            with file_path.open("r", encoding="utf-8") as f:
                data = json.load(f)
                
        except Exception as e:
            parse_errors.append((file_path, str(e)))
            continue

        if isinstance(data, dict) and "rounds" in data:
            files_with_key += 1
            value = data["rounds"]
            counts[make_hashable(value)] += 1
            
            # Check if rounds value is greater than 1
            if isinstance(value, (int, float)) and value > 1:
                files_with_rounds_gt_1.append(file_path)
            elif isinstance(value, str):
                try:
                    # Try to convert string to number
                    num_value = float(value)
                    if num_value > 1:
                        files_with_rounds_gt_1.append(file_path)
                except ValueError:
                    pass  # Not a number, skip
        else:
            missing_key += 1

    # Output
    print(f"Scanned JSON files: {total_files}")
    print(f'Files with key "rounds": {files_with_key}')
    print(f'Files missing key "rounds": {missing_key}')
    print(f'Files with rounds > 1: {len(files_with_rounds_gt_1)}')
    if parse_errors:
        print(f"Files failed to parse: {len(parse_errors)}")

    if counts:
        print("\nUnique values and counts:")
        for value, cnt in counts.most_common():
            # Pretty print complex values
            if isinstance(value, str):
                # Could be a JSON-serialized dict
                try:
                    pretty = json.dumps(json.loads(value), ensure_ascii=False)
                except Exception:
                    pretty = value
                shown = pretty
            else:
                try:
                    shown = json.dumps(value, ensure_ascii=False)
                except Exception:
                    shown = str(value)
            print(f"{shown}\t{cnt}")
    else:
        print("\nNo values counted.")
    
    return counts, files_with_rounds_gt_1

# Get counts and file paths where rounds > 1
# counts, files_with_rounds_gt_1 = main("cladder","qwen3_thinking/multi1")
counts, files_with_rounds_gt_1 = main("corr","qwen32/multi")

# Display the file paths
print(f"\nFiles with rounds > 1:")
# for file_path in files_with_rounds_gt_1:
#     print(file_path)

len(files_with_rounds_gt_1)

# Convert Path objects to strings first, then split
labels=[str(f).split(".")[0].split("_")[-1].lower() for f in files_with_rounds_gt_1]
ids=[float(str(f).split(".")[0].split("_")[-2]) for f in files_with_rounds_gt_1]

# ids to be sent to self-consistency
import pandas as pd
df_res=pd.DataFrame(data={"id":ids,"label":labels})

df=pd.read_csv("../data/corr2cause/corr_test.csv")
# df=pd.read_csv("../data/CLadder/data/cladder_500.csv")
df.head()

# df['label'] = df['label'].map({1: 'yes', 0: 'no'})

merged=df.merge(df_res,on=['id'],how='inner')

merged.shape

merged.head()

# ## accuracy of multi-agent
# from sklearn.metrics import (
#     accuracy_score,
#     precision_recall_fscore_support,
#     classification_report,
#     confusion_matrix
# )

# y_true = merged['label_x']
# y_pred = merged['label_y']

# # Compute metrics
# accuracy = accuracy_score(y_true, y_pred)
# precision, recall, f1, _ = precision_recall_fscore_support(
#     y_true, y_pred, average='binary', pos_label='yes'
# )

# report = classification_report(y_true, y_pred, labels=['yes', 'no'])
# cm = confusion_matrix(y_true, y_pred, labels=['yes', 'no'])

# print(f"Accuracy: {accuracy*100:.2f}%")
# print(f"Precision (yes): {precision:.2f}")
# print(f"Recall (yes): {recall:.2f}")
# print(f"F1-score (yes): {f1:.2f}\n")
# print("Classification Report:\n", report)
# print("Confusion Matrix (rows=truth, cols=predicted):\n", cm)

merged.drop(columns=['label_y'],inplace=True)

merged.head()

merged.columns=['input','label','num_variables','template','id']
# merged.columns=['id','prompt','label','reasoning','rung','query_type','graph_id','story_id','question_property','formal_form']

merged.to_csv("../data/corr2cause/corr_qwen32_self.csv",index=False)

# merged.to_csv("../data/CLadder/data/cladder_qwen32_self.csv",index=False)

from sklearn.metrics import accuracy_score

accuracy = accuracy_score(merged['label_y'], merged['label_x'])
print(f"Accuracy: {accuracy:.4f}")
