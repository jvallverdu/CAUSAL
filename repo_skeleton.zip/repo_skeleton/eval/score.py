"""Per-cell accuracy scoring.

Scans the outputs/ directory tree and produces a per-(model, strategy)
accuracy + parse-failure summary, along with a flat per-item CSV that
downstream analyses (mcnemar, bootstrap, figures) consume.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

OUTPUTS_ROOT = Path("outputs")


def score_cell(cell_dir: Path) -> dict:
    rows = []
    for f in sorted(cell_dir.glob("*.json")):
        d = json.loads(f.read_text())
        rows.append({
            "item_id": d.get("item_id"),
            "ground_truth": d.get("ground_truth"),
            "predicted": d.get("predicted") or d.get("final_answer"),
            "latency_seconds": d.get("latency_seconds"),
            "input_tokens": d.get("input_tokens"),
            "output_tokens": d.get("output_tokens"),
            "raw_response_chars": len(d.get("raw_response", "")),
        })
    n = len(rows)
    valid = [r for r in rows if r["predicted"] in {"YES", "NO"}]
    correct = sum(1 for r in valid if r["predicted"] == r["ground_truth"])
    parse_fail = n - len(valid)
    return {
        "n": n,
        "n_valid": len(valid),
        "correct": correct,
        "accuracy": correct / len(valid) if valid else 0.0,
        "parse_fail_rate": parse_fail / n if n else 0.0,
        "rows": rows,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--benchmark", choices=["cladder", "corr2cause"], required=True)
    ap.add_argument("--exclude", nargs="*", default=[])
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--per-item-csv", type=Path,
                    default=Path("analysis/_built/per_item.csv"))
    args = ap.parse_args()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.per_item_csv.parent.mkdir(parents=True, exist_ok=True)

    bench_root = OUTPUTS_ROOT / args.benchmark
    summary_lines = []
    per_item_rows = []
    for model_dir in sorted(bench_root.iterdir()):
        if not model_dir.is_dir() or model_dir.name in args.exclude:
            continue
        for strat_dir in sorted(model_dir.iterdir()):
            if not strat_dir.is_dir():
                continue
            res = score_cell(strat_dir)
            summary_lines.append(
                f"{model_dir.name} & {strat_dir.name} & "
                f"{res['accuracy']*100:.2f} & {res['n_valid']} \\\\"
            )
            for r in res["rows"]:
                r["model"] = model_dir.name
                r["strategy"] = strat_dir.name
                r["benchmark"] = args.benchmark
                per_item_rows.append(r)

    args.out.write_text("\n".join(summary_lines))
    with open(args.per_item_csv, "w", newline="") as f:
        if per_item_rows:
            w = csv.DictWriter(f, fieldnames=list(per_item_rows[0].keys()))
            w.writeheader()
            w.writerows(per_item_rows)
    print(f"[OK] {args.out} ({len(summary_lines)} cells, {len(per_item_rows)} items)")


if __name__ == "__main__":
    main()
