"""Tokenizer calibration (Appendix A).

For each model family used in the paper, picks 50 multi-agent reasoning
traces at random, compares the chars/3.7 approximator against the actual
tokenizer's count, and reports the mean chars-per-token ratio plus the
maximum absolute relative error of the approximator.

Requires `transformers` (only for this script).
"""
from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

try:
    from transformers import AutoTokenizer
    HAVE_HF = True
except ImportError:
    HAVE_HF = False

# Map paper-family-name -> a tokenizer hub id that's representative
TOKENIZERS = {
    "Qwen2.5/Qwen3":     "Qwen/Qwen2.5-7B",
    "Llama-3.1":          "meta-llama/Llama-3.1-8B",
    "Falcon-3":           "tiiuae/Falcon3-7B-Instruct",
    "Gemma-3":            "google/gemma-2-9b",
    "Phi-4":              "microsoft/phi-4",
    "DeepSeek-R1-distill":"deepseek-ai/DeepSeek-R1-Distill-Llama-8B",
    "QwQ":                "Qwen/QwQ-32B-Preview",
}


def calibrate(family: str, hub_id: str, traces_dir: Path, n: int = 50,
              seed: int = 42) -> dict:
    if not HAVE_HF:
        raise RuntimeError("Install transformers to run calibration.")
    tok = AutoTokenizer.from_pretrained(hub_id, trust_remote_code=True)
    files = list(traces_dir.glob("*.json"))
    rng = random.Random(seed)
    chosen = rng.sample(files, min(n, len(files)))

    ratios, biases = [], []
    for f in chosen:
        d = json.loads(f.read_text())
        # Concatenate every reasoner / validator response in the conversation
        text = ""
        for c in d.get("conversation", []):
            text += c.get("raw_response", "") + "\n"
        if not text.strip():
            continue
        true_tokens = len(tok.encode(text, add_special_tokens=False))
        approx = len(text) / 3.7
        ratios.append(len(text) / true_tokens)
        biases.append(abs(approx - true_tokens) / true_tokens)

    return {
        "family": family,
        "hub_id": hub_id,
        "n": len(ratios),
        "chars_per_token_mean": sum(ratios) / len(ratios),
        "chars_per_token_std":  (sum((x - sum(ratios)/len(ratios))**2
                                       for x in ratios) / len(ratios)) ** 0.5,
        "max_bias_pct": 100 * max(biases),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--traces-root", type=Path, default=Path("calibration/traces"))
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()

    args.out.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for family, hub_id in TOKENIZERS.items():
        traces_dir = args.traces_root / family.replace("/", "_")
        if not traces_dir.exists():
            print(f"[skip] {family}: no traces in {traces_dir}")
            continue
        try:
            r = calibrate(family, hub_id, traces_dir)
            rows.append(r)
            print(f"[OK] {family}: {r['chars_per_token_mean']:.2f} cpt, "
                  f"max bias {r['max_bias_pct']:.1f}%")
        except Exception as e:
            print(f"[fail] {family}: {e}")

    with open(args.out, "w") as f:
        for r in rows:
            f.write(f"{r['family']} & --- & "
                    f"${r['chars_per_token_mean']:.2f} \\pm {r['chars_per_token_std']:.2f}$ & "
                    f"${r['max_bias_pct']:.1f}$ \\\\\n")


if __name__ == "__main__":
    main()
