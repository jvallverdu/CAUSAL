# Memorization audit

Implements the contamination probe of Shi et al. (2023).

## What this measures

For each (model, benchmark) pair: the average min-K log-likelihood on the
original benchmark text vs. on lightly paraphrased variants. Models that
assign disproportionately high likelihood (low perplexity) to benchmark
text but not to paraphrased text are flagged as having likely seen the
benchmark during pretraining.

## Decision rule (paper, Section 5.5)

A model is flagged as **likely contaminated** on a benchmark when both:

  *  metric value `< 0.1`, AND
  *  percentage above the detection threshold `> 85%`

Phi-4 and QwQ-32b are flagged on Corr2Cause; no model is flagged on
CLadder.

## Files

| File                        | Purpose                                          |
|-----------------------------|--------------------------------------------------|
| `memorization.py`           | Orchestrator + LaTeX writer                      |
| `paraphrase_templates.txt`  | The lexical paraphrase rules (synonym swaps)     |
| `audit_results.json`        | Cached probe outputs (so the table is fast)      |

## Re-running from scratch

The probes use token-level log-probabilities, which require an inference
backend that exposes per-token logits (the standard Ollama API does not).
We used the `ollama --logits` extension; a fallback is provided that
reads the cached `audit_results.json` so reviewers can regenerate Table 8
without re-probing.

```bash
make audit             # uses cached audit_results.json (~5 seconds)
```
