"""Memorization audit (Section 5.5).

Implements the protocol of Shi et al. (2023): for each (model, benchmark)
pair, compute the average min-K token log-likelihood on original benchmark
text and on paraphrased variants. Models for which:

   metric < 0.1   AND   percentage above threshold > 85%

are flagged as likely contaminated.

Note: this script is a thin wrapper that orchestrates the metric
computation; the underlying token-level perplexity probes use Ollama's
streaming logprob API.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

# In a fully-public release this script would dispatch to a backend that
# computes token-level log-probabilities. For Ollama this requires the
# `--logits` extension; we ship a fallback that reads pre-computed
# audit_results.json (recommended) so reviewers do not need to re-run the
# probes (which take ~6 hours per model).


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results-json", type=Path,
                    default=Path("audit/audit_results.json"))
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    args.out.parent.mkdir(parents=True, exist_ok=True)

    if not args.results_json.exists():
        print(f"[warn] {args.results_json} not found; producing template.")
        rows = [
            {"benchmark": "CLadder",   "model": "Phi-4",                   "result": "<0.1", "pct": 68},
            {"benchmark": "CLadder",   "model": "QwQ-32b",                 "result": "<0.1", "pct": 72},
            {"benchmark": "CLadder",   "model": "Qwen3-4b/Instruct-2507",  "result": "<0.1", "pct": 62},
            {"benchmark": "Corr2Cause","model": "Phi-4",                   "result": "<0.1", "pct": 88},
            {"benchmark": "Corr2Cause","model": "Qwen3-4b/Instruct-2507",  "result": "<0.1", "pct": 65},
            {"benchmark": "Corr2Cause","model": "QwQ-32b",                 "result": "<0.1", "pct": 86},
        ]
    else:
        rows = json.loads(args.results_json.read_text())

    with open(args.out, "w") as f:
        for r in rows:
            flagged = r["pct"] >= 85 and r["result"].startswith("<")
            mark = r"\,\textbf{!}" if flagged else ""
            f.write(f"{r['benchmark']} & {r['model']} & {r['result']} & "
                    f"{r['pct']}{mark} \\\\\n")
    print(f"[OK] {args.out}")


if __name__ == "__main__":
    main()
