# Notation cheat-sheet

This document mirrors Section 3.2 of the paper, where the notation was
re-organised in response to Reviewer 1 (round 2) who flagged the original
re-use of the symbol `tau` for both the consensus threshold and the
sampling temperature.

## The four scalar parameters of the multi-agent framework

| Symbol  | Range           | Default | Meaning                                                                |
|---------|-----------------|---------|------------------------------------------------------------------------|
| `A`     | {2, 3, 5, ...}  | 3       | Number of reasoner agents.                                             |
| `tau_c` | [0.5, 1.0]      | 0.9     | Consensus threshold: minimum fraction of reasoners that must agree.    |
| `R`     | {1, 2, 4, ...}  | 4       | Maximum number of debate rounds.                                       |
| `V`     | {on, off}       | on      | Whether the validator agent is included between rounds.                |

## The decoding parameters

| Symbol  | Range          | Default | Meaning                                                          |
|---------|----------------|---------|------------------------------------------------------------------|
| `T`     | (0, 2]         | 0.7     | Sampling temperature passed to the inference engine.             |
| `top_p` | (0, 1]         | 0.9     | Nucleus sampling probability cutoff.                             |
| `top_k` | positive int   | 40      | Top-K sampling cutoff.                                           |
| `K`     | positive int   | 5       | Number of self-consistency samples (single-agent only).          |

## What changed in this revision

* The symbol `tau` (without subscript) is reserved for the consensus
  threshold. We always write `tau_c` in the LaTeX where there is any
  possibility of ambiguity.
* The sampling temperature is always written `T`.
* In the previous revision the ablation grid used `tau` to mean
  temperature in places. This has been corrected throughout.
