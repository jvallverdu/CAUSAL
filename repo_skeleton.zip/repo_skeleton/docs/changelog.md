# Changelog

## Round 2 -> Round 3 (this revision)

### Methodology
* **Notation disambiguation.** The symbol `tau` is now reserved for the
  consensus threshold, written `tau_c` where ambiguity is possible. The
  sampling temperature is always `T`. (Reviewer 1, point 3.)
* **Heterogeneous configurations** (HET-1, HET-2) are fully specified:
  per-agent model identity, role assignment, decoding parameters,
  aggregation rule, and validator-feedback handling. See
  `prompts/het*_system_prompts.json`. (Reviewer 1, point 4.)
* **Self-consistency** is fully specified: K=5 samples with seeds 1..5,
  log-probability tie-breaking. (Editor, point 2.)

### Statistical analysis
* **Per-pair McNemar table** (Table 9) replaces the previous narrative
  summary, with `b`, `c`, `n`, `chi^2`, raw `p`, BH-adjusted `p`, Cliff's
  delta, and Wald 95% CI for every comparison. (Reviewer 1, point 6.)
* **Bootstrap CIs** are now BCa rather than percentile, in
  `analysis/bootstrap.py`.

### Efficiency
* **Disaggregated efficiency profile** (Appendix B Table 14): latency per
  query, mean input tokens, mean output tokens, mean number of inference
  calls, mean total tokens, throughput. Throughput is no longer conflated
  with practical computational cost. (Reviewer 1, point 5.)
* **Tokenizer calibration** appendix (Appendix A) added; documents the
  chars/3.7 approximator and bounds its bias at <8%. (Editor, point 3;
  Reviewer 1, point 5.)

### Ablation
* **Acknowledgement** that the agreement-based bound is not the same as
  ground-truth accuracy is now prominent in the section text and in the
  Limitations. The implied accuracy intervals are tightened with explicit
  worst-case math. Direct ground-truth scoring will be added in the
  camera-ready. (Reviewer 1, point 1.)
* **51/72 completion** is now stated in bold in both the abstract-level
  contribution list and the ablation section, not only in a footnote.
  (Editor, point 4.)
* **Auxiliary tau_c sweep** (51% / 66% / 90%) added as a robustness check.
  (Reviewer 1, point 2.)

### Reproducibility
* **Anonymous repository** is available at the URL given in the
  Data and Code Availability section, containing prompts, sampled item
  IDs, runners, evaluation scripts, audit code, ablation outputs, raw
  per-item predictions, and figure-generation scripts. (Editor, point 1.)
* The `data/sampled_ids/sample_ids.py` deterministic script is included.

### Presentation
* The spurious "immediate" line on the title page (an `authblk` artifact)
  is removed. (Reviewer 1, point 7.)
* Caption mismatches in figures `cladder_gain_vanilla_acc.pdf`,
  `corr_gain_vanilla_acc.pdf`, and the throughput-vs-size scatter plots
  are corrected. (Reviewer 1, point 7.)
* All figures regenerated with non-overlapping axis labels, fixing
  Figure 7's overlap. (Reviewer 2.)
* `CLadder` capitalization is normalised throughout via the `\CLadder`
  macro.
* Stale references like `\ref{sec:token_analysis}` -> `\ref{sec:token_count}`.

## Round 1 -> Round 2 (previous revision)
* Added bootstrap CIs.
* Added paired McNemar tests.
* Added contamination audit (Section 5.5).
* Added preliminary multi-agent hyperparameter ablation.
* Softened broad multi-agent claims throughout.
